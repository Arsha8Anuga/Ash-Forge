public class SmelterWorkstation :
    WorkstationBase
{
}