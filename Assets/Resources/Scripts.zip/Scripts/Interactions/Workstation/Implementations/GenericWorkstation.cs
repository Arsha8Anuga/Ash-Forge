public class GenericWorkstation :
    WorkstationBase
{
}