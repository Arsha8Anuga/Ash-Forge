public class AssemblyDisassemblyWorkbench :
    WorkstationBase
{
}